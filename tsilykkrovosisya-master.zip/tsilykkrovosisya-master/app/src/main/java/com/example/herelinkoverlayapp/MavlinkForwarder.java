package com.example.herelinkoverlayapp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class MavlinkForwarder extends Thread {

    private static final int SOURCE_PORT = 14550;
    private static final int TARGET_PORT = 14552;

    @Override
    public void run() {
        try {
            DatagramSocket inputSocket = new DatagramSocket();  // Без bind
            inputSocket.connect(InetAddress.getByName("127.0.0.1"), SOURCE_PORT);

            DatagramSocket forwardSocket = new DatagramSocket();
            byte[] buffer = new byte[1024];

            while (true) {
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                inputSocket.receive(packet);

                DatagramPacket forwardPacket = new DatagramPacket(
                        packet.getData(),
                        packet.getLength(),
                        InetAddress.getByName("127.0.0.1"),
                        TARGET_PORT
                );
                forwardSocket.send(forwardPacket);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
