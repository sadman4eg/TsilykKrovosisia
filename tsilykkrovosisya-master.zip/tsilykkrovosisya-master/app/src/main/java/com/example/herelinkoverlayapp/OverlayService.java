package com.example.herelinkoverlayapp;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.provider.Settings;
import android.net.Uri;
import android.widget.Toast;
import android.util.Log;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.content.Context;


import com.example.herelinkoverlayapp.DroneStateListener;


import androidx.annotation.Nullable;


public class OverlayService extends Service {

    private WindowManager windowManager;
    private View overlayView;
    private SharedPreferences preferences;

    private View movingView;
    private View menuOverlayView;
    private Handler handler = new Handler();
    private Runnable updateTask;

    private int screenWidth;
    private int screenHeight;
    private int availableScreenHeight;
    private int qgroundTopMenuHeightPx = 110;

    private float lastX = -1;
    private float lastY = -1;

    private DroneState latestDroneState;

    private boolean isOverlayRunning;
    private boolean isMenuVisible;

    private double currentPitch = 0.0;
    private double currentRoll = 0.0;

    private WindowManager.LayoutParams movingParams;
    private WindowManager.LayoutParams menuParams;

    private MavLinkReceiver mavLinkReceiver; // Додаємо сюди


    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        int layoutFlag;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            layoutFlag = WindowManager.LayoutParams.TYPE_PHONE;
        }

        // Меню
        menuOverlayView = LayoutInflater.from(this).inflate(R.layout.overlay_menu_layout, null);

        preferences = getSharedPreferences("Settings", MODE_PRIVATE);

        overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_layout, null);

        ImageView overlayIcon = overlayView.findViewById(R.id.overlayIcon);

        // Читаємо налаштування
        String iconColorString = preferences.getString("iconColor", "#FFFFFF");
        int iconSize;
        try {
            iconSize = Integer.parseInt(preferences.getString("iconSize", "48"));
        } catch (NumberFormatException e) {
            iconSize = 48;
        }

        int iconOpacity;
        try {
            iconOpacity = Integer.parseInt(preferences.getString("iconOpacity", "100"));
        } catch (NumberFormatException e) {
            iconOpacity = 100;
        }

        boolean outlineOnly = preferences.getBoolean("outlineOnly", false);

        // Формуємо Drawable для іконки
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.OVAL);

        try {
            if (outlineOnly) {
                drawable.setColor(Color.TRANSPARENT);
                drawable.setStroke(4, Color.parseColor(iconColorString));
            } else {
                drawable.setColor(Color.parseColor(iconColorString));
            }
        } catch (IllegalArgumentException e) {
            drawable.setColor(Color.WHITE); // fallback якщо колір кривий
        }

        // Встановлюємо у ImageView
        overlayIcon.setImageDrawable(drawable);
        overlayIcon.setAlpha(Math.min(Math.max(iconOpacity, 0), 100) / 100.0f); // 0-100%

        WindowManager.LayoutParams menuParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutFlag,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );

        menuParams.gravity = Gravity.BOTTOM | Gravity.START;
        menuParams.x = 0;
        menuParams.y = 130;

        windowManager.addView(menuOverlayView, menuParams);

        // Крапка
        movingView = new View(this);

        // Формуємо Drawable для крапки
        GradientDrawable movingDrawable = new GradientDrawable();
        movingDrawable.setShape(GradientDrawable.OVAL);

        try {
            if (outlineOnly) {
                movingDrawable.setColor(Color.TRANSPARENT);
                movingDrawable.setStroke(2, Color.parseColor(iconColorString)); // трохи тонший бордер для точки
            } else {
                movingDrawable.setColor(Color.parseColor(iconColorString));
            }
        } catch (IllegalArgumentException e) {
            movingDrawable.setColor(Color.WHITE);
        }

        movingView.setBackground(movingDrawable);
        movingView.setAlpha(Math.min(Math.max(iconOpacity, 0), 100) / 100.0f);
        movingView.setVisibility(View.GONE);

        // Розмір крапки також під конфіги
        movingParams = new WindowManager.LayoutParams(
                iconSize,
                iconSize,
                layoutFlag,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );
        movingParams.gravity = Gravity.CENTER;
        windowManager.addView(movingView, movingParams);

        // Кнопки
        Button startButton = menuOverlayView.findViewById(R.id.startButton);
        Button toggleMenuButton = menuOverlayView.findViewById(R.id.toggleMenuButton);
        ImageButton settingsButton = menuOverlayView.findViewById(R.id.settingsButton);

        // Кнопка ON/OFF
        startButton.setOnClickListener(v -> {
            if (isOverlayRunning) {
                isOverlayRunning = false;
                startButton.setText("ON");
                startButton.setBackgroundTintList(getColorStateList(android.R.color.holo_green_light));
                movingView.setVisibility(View.GONE);
            } else {
                isOverlayRunning = true;
                startButton.setText("OFF");
                startButton.setBackgroundTintList(getColorStateList(android.R.color.holo_red_light));
                movingView.setVisibility(View.VISIBLE);
                updateOverlayPosition();
            }
        });

        // Кнопка стрілочки
        toggleMenuButton.setText("◀");
        isMenuVisible = true;

        toggleMenuButton.setOnClickListener(v -> {
            if (isMenuVisible) {
                startButton.setVisibility(View.GONE);
                settingsButton.setVisibility(View.GONE);
                toggleMenuButton.setText("▶");
                isMenuVisible = false;
            } else {
                startButton.setVisibility(View.VISIBLE);
                settingsButton.setVisibility(View.VISIBLE);
                toggleMenuButton.setText("◀");
                isMenuVisible = true;
            }
        });

        // Кнопка налаштувань
        settingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, SettingsActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        });

        // Екран
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        screenWidth = metrics.widthPixels;
        screenHeight = metrics.heightPixels;
        availableScreenHeight = screenHeight - qgroundTopMenuHeightPx;

        startUpdatingOverlay();

        // Стартуємо mavlink прийом даних
        mavLinkReceiver = new MavLinkReceiver();
        mavLinkReceiver.setMavLinkListener(new MavLinkListener() {
            @Override
            public void onAttitudeUpdate(double roll, double pitch) {
                currentRoll = roll;
                currentPitch = pitch;
//                Log.i("OverlayService", "Attitude updated: roll=" + roll + ", pitch=" + pitch);

            }
        });

        mavLinkReceiver.setDroneStateListener(new DroneStateListener() {
            @Override
            public void onDroneStateUpdate(DroneState droneState) {
                latestDroneState = droneState;

//                Log.d("OverlayService", "Drone State Updated: Lat=" + droneState.getLatitude() +
//                        " Lon=" + droneState.getLongitude() +
//                        " AltMSL=" + droneState.getAltitudeMSL() +
//                        " RealAltAboveGround=" + droneState.getRealAltitudeAboveGround());
            }
        });
        mavLinkReceiver.start();
    }


    private void startUpdatingOverlay() {
        updateTask = new Runnable() {
            @Override
            public void run() {
                updateOverlayPosition();
                handler.postDelayed(this, 50);
            }
        };
        handler.post(updateTask);
    }


    private float smoothedAltitude = -1f;

    private void updateOverlayPosition() {
        if (!isOverlayRunning || movingView == null || movingView.getVisibility() != View.VISIBLE || latestDroneState == null) {
            return;
        }

        // 1. Дані з телеметрії
        float altitude = (float) latestDroneState.getRealAltitudeAboveGround();
        float globalVx = latestDroneState.getVelocityX(); // Схід
        float globalVy = latestDroneState.getVelocityY(); // Північ
        float yawDegrees = latestDroneState.getYaw();     // В градусах
        float pitch = (float) currentPitch;
        float roll = (float) currentRoll;

        // 2. Вектор вітру
        DropCorrectionCalculator.Vector2 wind = DropCorrectionCalculator.ManualWindSettings.getWindVector();

        // 3. Параметри снаряда з налаштувань
        SharedPreferences prefs = getSharedPreferences("Settings", Context.MODE_PRIVATE);

        float mass = Float.parseFloat(prefs.getString("projectileMass", "3.3"));
        float diameter = Float.parseFloat(prefs.getString("projectileDiameter", "0.082"));
        float drag = Float.parseFloat(prefs.getString("projectileDrag", "0.12"));

        String dropModeStr = prefs.getString("dropMode", "LOITER");

        DropCorrectionCalculator.DropMode dropMode = DropCorrectionCalculator.DropMode.valueOf(dropModeStr);

        DropCorrectionCalculator.Projectile projectile = new DropCorrectionCalculator.Projectile(mass, diameter, drag);

        DropCorrectionCalculator.Vector2 correction;

        if (dropMode == DropCorrectionCalculator.DropMode.ALTHOLD) {
            // 4. Поворот швидкості у локальну систему координат дрона
            float yawRad = (float) Math.toRadians(yawDegrees);
            float cosYaw = (float) Math.cos(-yawRad);
            float sinYaw = (float) Math.sin(-yawRad);

            // Обертаємо з глобальної (ENU) в локальну систему дрона
            float localVx = globalVx * cosYaw - globalVy * sinYaw; // X — ліво/вправо
            float localVy = globalVx * sinYaw + globalVy * cosYaw; // Y — вперед/назад

            correction = DropCorrectionCalculator.calculateCorrectionAltHold(
                    altitude,
                    localVx,
                    localVy,
                    wind.x,
                    wind.y,
                    projectile
            );
        } else {
            correction = DropCorrectionCalculator.calculateCorrectionLoiter(
                    altitude, pitch, roll, wind.x, wind.y, projectile
            );
        }

        float offsetX_meters = correction.x;
        float offsetY_meters = correction.y;

        // 6. Масштаб пікселів до метрів
        float baseScale = 1000.0f;
        float metersToPixels = baseScale / altitude;
        metersToPixels = Math.max(1.0f, Math.min(metersToPixels, 80.0f));

        // 7. Екранні координати
        float xOffsetPx = (screenWidth / 2f) + (offsetX_meters * metersToPixels);
        float yOffsetPx = (qgroundTopMenuHeightPx + (availableScreenHeight / 2f)) + (offsetY_meters * metersToPixels);

        int targetX = (int) (xOffsetPx - screenWidth / 2f);
        int targetY = (int) (yOffsetPx - screenHeight / 2f);

        // 8. Анімація крапки
        if (lastX == -1 && lastY == -1) {
            movingParams.x = targetX;
            movingParams.y = targetY;
            windowManager.updateViewLayout(movingView, movingParams);
        } else {
            animateMovement((int) lastX, (int) lastY, targetX, targetY);
        }

        lastX = targetX;
        lastY = targetY;
    }


    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);

        // Прибираємо меню
        if (menuOverlayView != null) {
            try {
                windowManager.removeView(menuOverlayView);
            } catch (Exception e) {
                Log.e("OverlayService", "menuOverlayView remove error: " + e.getMessage());
            }
            menuOverlayView = null;
        }

        // Прибираємо крапку
        if (movingView != null) {
            try {
                windowManager.removeView(movingView);
            } catch (Exception e) {
                Log.e("OverlayService", "movingView remove error: " + e.getMessage());
            }
            movingView = null;
        }

        // Зупиняємо сам сервіс
        stopSelf();
    }


    private void animateMovement(int fromX, int fromY, int toX, int toY) {
        final int startX = fromX;
        final int startY = fromY;
        final int deltaX = toX - fromX;
        final int deltaY = toY - fromY;

        final long duration = 50; // анімація за 50 мс

        final long startTime = System.currentTimeMillis();

        handler.post(new Runnable() {
            @Override
            public void run() {
                float elapsed = (System.currentTimeMillis() - startTime) / (float) duration;
                if (elapsed > 1f) elapsed = 1f;

                int currentX = startX + (int) (deltaX * elapsed);
                int currentY = startY + (int) (deltaY * elapsed);

                movingParams.x = currentX;
                movingParams.y = currentY;
                windowManager.updateViewLayout(movingView, movingParams);

                if (elapsed < 1f) {
                    handler.postDelayed(this, 16); // ~60fps
                }
            }
        });
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(updateTask);

        if (menuOverlayView != null) {
            windowManager.removeView(menuOverlayView);
        }
        if (movingView != null) {
            windowManager.removeView(movingView);
        }
        if (mavLinkReceiver != null) {
            mavLinkReceiver.stopReceiver();
            mavLinkReceiver = null;
        }
    }
}
