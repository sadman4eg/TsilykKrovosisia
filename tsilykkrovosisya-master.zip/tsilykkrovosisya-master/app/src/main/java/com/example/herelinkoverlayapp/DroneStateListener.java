package com.example.herelinkoverlayapp;

public interface DroneStateListener {
    void onDroneStateUpdate(DroneState droneState);
}