package com.example.herelinkoverlayapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import androidx.core.content.ContextCompat;

public class ColorAdapter extends BaseAdapter {

    private final Context context;
    private final String[] colors;

    public ColorAdapter(Context context, String[] colors) {
        this.context = context;
        this.colors = colors;
    }

    @Override
    public int getCount() {
        return colors.length;
    }

    @Override
    public Object getItem(int position) {
        return colors[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_color, parent, false);
        }

        View colorView = convertView.findViewById(R.id.colorView);

        try {
            colorView.setBackgroundColor(android.graphics.Color.parseColor(colors[position]));
        } catch (IllegalArgumentException e) {
            colorView.setBackgroundColor(ContextCompat.getColor(context, android.R.color.darker_gray));
        }

        return convertView;
    }
}
