package com.example.herelinkoverlayapp;

import android.util.Log;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;

public class MavLinkReceiver extends Thread {

    private static final String TAG = "MavLinkReceiver";
    private DatagramSocket socket;
    private volatile boolean running = false; // volatile для потоків
    private final int port = 14552; // обираємо порт 14552, бо 14550 зайнятий

    private MavLinkListener mavLinkListener;

    private boolean startAltCaptured = false;
    private double startAltMSL = 0.0;

    private List<Double> hdopValues = new ArrayList<>();
    private final int HDOP_VALUES_LIMIT = 10;
    private boolean hdopStable = false;
    private float latestYawDegrees = 0f;


    private DroneStateListener droneStateListener;


    public void setMavLinkListener(MavLinkListener listener) {
        this.mavLinkListener = listener;
    }

    public void setDroneStateListener(DroneStateListener listener) {
        this.droneStateListener = listener;
    }

    @Override
    public void run() {
        try {
            socket = new DatagramSocket();
            try {
                socket.connect(InetAddress.getByName("127.0.0.1"), port);
            } catch (IOException e) {
                Log.e(TAG, "Помилка при підключенні сокета: " + e.getMessage());
            }
            socket.setSoTimeout(15000);

            sendInitialProbe();

            running = true;
            byte[] buffer = new byte[1500];

            while (running) {
                if (socket.isClosed()) {
                    break;
                }

                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                try {
                    socket.receive(packet);
                    parseMavlinkPacket(packet.getData(), packet.getLength());

                } catch (SocketTimeoutException e) {
                    Log.i(TAG, "Таймаут отримання: " + e.getMessage());
                } catch (IOException e) {
                    if (running) {
                        Log.e(TAG, "Помилка прийому: " + e.getMessage());
                    } else {
                        // Сокет закритий спеціально, можна ігнорити
                        Log.i(TAG, "Сокет закритий, зупиняємось");
                        break;
                    }
                }
            }
        } catch (SocketException e) {
            Log.e(TAG, "Помилка створення сокета: " + e.getMessage());
        }
    }

    private float bytesToFloat(byte[] array, int index) {
        int asInt = (array[index] & 0xFF) |
                ((array[index + 1] & 0xFF) << 8) |
                ((array[index + 2] & 0xFF) << 16) |
                ((array[index + 3] & 0xFF) << 24);
        return Float.intBitsToFloat(asInt);
    }


    private int getInt16(byte[] buffer, int index) {
        return (short) ((buffer[index] & 0xFF) | ((buffer[index + 1] & 0xFF) << 8));
    }

    private void parseMavlinkPacket(byte[] data, int length) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append(String.format("%02X ", data[i]));
        }
//        Log.d("MAVLink", "HEX: " + sb.toString());

        if (length < 17) {
//            Log.d("MAVLink", "Packet too short: " + length);

            return; // Занадто короткий для MAVLink2
        }

        if ((data[0] & 0xFF) != 0xFD) {
            Log.d("MAVLink", "Not MAVLink2 packet: " + String.format("%02X", data[0]));

            return; // Не MAVLink 2.0 пакет
        }

        int payloadLength = data[1] & 0xFF;
        int msgid = (data[9] & 0xFF) << 16 | (data[8] & 0xFF) << 8 | (data[7] & 0xFF);
//        Log.d("MAVLink", "msgid: " + msgid);

        if (msgid == 24) { // GPS_RAW_INT
            if (payloadLength < 30) {
                return;
            }

            int payloadStart = 10;

            int ephRaw = getInt16(data, payloadStart + 10); // eph — на 10 offset
            double hdop = ephRaw / 10000.0;

//            Log.i("MAVLINK", "HDOP = " + hdop + ", timestamp = " + System.currentTimeMillis());


            // Додаємо в список
            if (hdop > 0 && hdop <= 1.5) { // тільки якщо HDOP адекватний
                hdopValues.add(hdop);
            }

            // Якщо зібрали 10 значень
            if (hdopValues.size() >= HDOP_VALUES_LIMIT && !hdopStable) {
                double sum = 0;
                for (double val : hdopValues) {
                    sum += val;
                }
                double avgHdop = sum / hdopValues.size();
                Log.i("MAVLink", "Середній HDOP = " + avgHdop);

                if (avgHdop < 1.5) { // наприклад якщо середній HDOP < 1.5
                    hdopStable = true;
                    Log.i("MAVLink", "HDOP стабільний. Можна фіксувати висоту!");
                } else {
                    // Якщо середній HDOP поганий — очищаємо список і пробуємо збирати ще раз
                    hdopValues.clear();
                    Log.i("MAVLink", "HDOP нестабільний. Очікуємо кращий сигнал...");
                }
            }
        }


        if (msgid == 30) { // ATTITUDE
            if (payloadLength < 28) {
                return;
            }

            int payloadStart = 10;

            float roll = bytesToFloat(data, payloadStart + 4);
            float pitch = bytesToFloat(data, payloadStart + 8);
            float yaw = bytesToFloat(data, payloadStart + 12); // у радіанах

            double rollDegrees = Math.toDegrees(roll);
            double pitchDegrees = Math.toDegrees(pitch);

            float yawDegrees = (float) Math.toDegrees(yaw);
            if (yawDegrees < 0) yawDegrees += 360;

            latestYawDegrees = yawDegrees;

            if (mavLinkListener != null) {
                mavLinkListener.onAttitudeUpdate(rollDegrees, pitchDegrees);
            }

//            Log.i("keck", "rollDegrees: " + rollDegrees);
//            Log.i("keck", "pitchDegrees: " + pitchDegrees);
        }

        if (msgid == 33) { // GLOBAL_POSITION_INT
            if (payloadLength < 28) {
                return;
            }

            int payloadStart = 10;

            int latRaw = getInt32(data, payloadStart + 4);
            int lonRaw = getInt32(data, payloadStart + 8);
            int altRaw = getInt32(data, payloadStart + 12);
            int relativeAltRaw = getInt32(data, payloadStart + 16);
            int vx = getInt16(data, payloadStart + 20); // cm/s
            int vy = getInt16(data, payloadStart + 22); // cm/s

            float velocityX = vx / 100.0f; // m/s
            float velocityY = vy / 100.0f; // m/s

            double latitude = latRaw / 1e7;
            double longitude = lonRaw / 1e7;
            double altitudeMSL = altRaw / 1000.0; // в метрах
            double relativeAltitude = relativeAltRaw / 1000.0; // в метрах

            if (true) {
                if (!startAltCaptured) {
                    startAltMSL = altitudeMSL;
                    startAltCaptured = true;
                    Log.i("MAVLink", "Captured start AltMSL: " + startAltMSL + " m");
                }


                double realAltitudeAboveGround = Math.max(0.0, altitudeMSL - startAltMSL);

                // Оновлюємо DroneState
                DroneState currentDroneState = new DroneState(
                        latitude,
                        longitude,
                        altitudeMSL,
                        realAltitudeAboveGround,
                        velocityX,
                        velocityY
                        );
                currentDroneState.setYaw(latestYawDegrees);


                if (droneStateListener != null) {
                    droneStateListener.onDroneStateUpdate(currentDroneState);
                }

                Log.d("MAVLink", "GPS: Lat=" + latitude + " Lon=" + longitude +
                        " AltMSL=" + altitudeMSL + "m RelAlt=" + relativeAltitude + "m" +
                        " RealAltAboveGround=" + realAltitudeAboveGround + "m" + " velocityX: " + velocityX +  " velocityY: " + velocityY);
            }
        }
    }

    private int getInt32(byte[] buffer, int index) {
        return (buffer[index] & 0xFF) |
                ((buffer[index + 1] & 0xFF) << 8) |
                ((buffer[index + 2] & 0xFF) << 16) |
                ((buffer[index + 3] & 0xFF) << 24);
    }

    private void sendInitialProbe() {
        try {
            InetAddress address = InetAddress.getByName("127.0.0.1");
            byte[] probe = new byte[1];
            DatagramPacket packet = new DatagramPacket(probe, probe.length, address, port);

            socket.send(packet);
            Log.i(TAG, "Початковий probe-пакет надіслано на порт " + port);

        } catch (IOException e) {
            Log.e(TAG, "Помилка надсилання probe-пакету: " + e.getMessage());
        }
    }

    public void stopReceiver() {
        running = false;
        if (socket != null && !socket.isClosed()) {
            socket.close();
            socket = null;
            Log.i(TAG, "Сокет закрито");
        }
    }
}
