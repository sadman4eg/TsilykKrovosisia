package com.example.herelinkoverlayapp;

public interface MavLinkListener {
    void onAttitudeUpdate(double roll, double pitch);
}