package com.example.herelinkoverlayapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import androidx.appcompat.app.AlertDialog;
import android.view.LayoutInflater;
import android.widget.ArrayAdapter;


public class SettingsActivity extends AppCompatActivity {

    private EditText heightInput, multiplierInput, baseHeightInput;
    private EditText iconColorInput, iconSizeInput, iconOpacityInput;
    private EditText projectileMassInput, projectileDiameterInput, projectileDragInput;

    private EditText windSpeedInput, windAzimuthInput;
    private CheckBox outlineOnlyCheckbox;
    private Button saveButton;

    private Button resetButton;

    private Spinner dropModeSpinner;



    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Підключення полів
//        heightInput = findViewById(R.id.heightInput);
//        multiplierInput = findViewById(R.id.multiplierInput);
//        baseHeightInput = findViewById(R.id.baseHeightInput);
        windSpeedInput = findViewById(R.id.windSpeedInput);
        windAzimuthInput = findViewById(R.id.windAzimuthInput);
        //
        projectileMassInput = findViewById(R.id.projectileMassInput);
        projectileDiameterInput = findViewById(R.id.projectileDiameterInput);
        projectileDragInput = findViewById(R.id.projectileDragInput);
        //
        iconColorInput = findViewById(R.id.iconColorInput);
        iconSizeInput = findViewById(R.id.iconSizeInput);
        iconOpacityInput = findViewById(R.id.iconOpacityInput);
        outlineOnlyCheckbox = findViewById(R.id.outlineOnlyCheckbox);
        //
        saveButton = findViewById(R.id.saveButton);
        resetButton = findViewById(R.id.resetButton);

        dropModeSpinner = findViewById(R.id.dropModeSpinner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.drop_mode_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dropModeSpinner.setAdapter(adapter);

        setupColorPicker();

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Скидання полів до стандартних значень
//                heightInput.setText("");
//                multiplierInput.setText("");
//                baseHeightInput.setText("");
                windSpeedInput.setText("0");
                windAzimuthInput.setText("0");
                //
                projectileMassInput.setText(preferences.getString("projectileMass", "3.3"));
                projectileDiameterInput.setText(preferences.getString("projectileDiameter", "0.082"));
                projectileDragInput.setText(preferences.getString("projectileDrag", "0.12"));
                //
                iconColorInput.setText("#FFFFFF");
                iconSizeInput.setText("48");
                iconOpacityInput.setText("100");
                outlineOnlyCheckbox.setChecked(false);

                // І одразу зберігаємо дефолтні значення
                saveSettings();
            }
        });

        preferences = getSharedPreferences("Settings", MODE_PRIVATE);

        loadSettings();

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSettings();
            }
        });
    }

    private void loadSettings() {
//        heightInput.setText(preferences.getString("height", ""));
//        multiplierInput.setText(preferences.getString("multiplier", ""));
//        baseHeightInput.setText(preferences.getString("baseHeight", ""));
        windAzimuthInput.setText(preferences.getString("windAzimuth", ""));
        windSpeedInput.setText(preferences.getString("windSpeed", ""));
        //
        projectileMassInput.setText(preferences.getString("projectileMass", "3.3"));
        projectileDiameterInput.setText(preferences.getString("projectileDiameter", "0.082"));
        projectileDragInput.setText(preferences.getString("projectileDrag", "0.12"));
        //
        iconColorInput.setText(preferences.getString("iconColor", "#FFFFFF"));
        iconSizeInput.setText(preferences.getString("iconSize", "48"));
        iconOpacityInput.setText(preferences.getString("iconOpacity", "100"));
        outlineOnlyCheckbox.setChecked(preferences.getBoolean("outlineOnly", false));

        String dropMode = preferences.getString("dropMode", "LOITER");
        if (dropMode.equals("ALTHOLD")) {
            dropModeSpinner.setSelection(1);
        } else {
            dropModeSpinner.setSelection(0);
        }
    }

    private void setupColorPicker() {
        String[] colorHex = {
                "#FF0000", "#00FFFF", "#0000FF", "#00FF00", "#FFFF00", "#800080", "#FFA500", "#008000",
                "#FFC0CB", "#000000", "#A52A2A", "#FFFFFF", "#808080", "#F5F5DC", "#40E0D0", "#E6E6FA",
                "#808000", "#00008B", "#C0C0C0", "#FFD700", "#FF7F50", "#006400", "#8B4513", "#AFEEEE",
                "#D3D3D3", "#4B0082", "#FFDAB9", "#C8A2C8", "#FFFACD", "#DC143C", "#FF00FF", "#FFE4C4",
                "#8B0000", "#9400D3", "#B0C4DE", "#D2691E", "#191970", "#98FB98"
        };

        iconColorInput.setFocusable(false);
        iconColorInput.setClickable(true);

        iconColorInput.setOnClickListener(v -> {
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
            builder.setTitle("Оберіть колір");

            View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_color_grid, null);
            android.widget.GridView gridView = dialogView.findViewById(R.id.colorGridView);
            gridView.setAdapter(new ColorAdapter(this, colorHex));

            android.app.AlertDialog dialog = builder.setView(dialogView).create();

            gridView.setOnItemClickListener((parent, view, position, id) -> {
                iconColorInput.setText(colorHex[position]);
                dialog.dismiss();
            });

            dialog.show();
        });
    }


    private void saveSettings() {
        SharedPreferences.Editor editor = preferences.edit();
//        editor.putString("height", heightInput.getText().toString());
//        editor.putString("multiplier", multiplierInput.getText().toString());
//        editor.putString("baseHeight", baseHeightInput.getText().toString());
        editor.putString("windSpeed", windSpeedInput.getText().toString());
        editor.putString("windAzimuth", windAzimuthInput.getText().toString());
        //
        editor.putString("projectileMass", projectileMassInput.getText().toString());
        editor.putString("projectileDiameter", projectileDiameterInput.getText().toString());
        editor.putString("projectileDrag", projectileDragInput.getText().toString());
        //
        editor.putString("iconColor", iconColorInput.getText().toString());
        editor.putString("iconSize", iconSizeInput.getText().toString());
        editor.putString("iconOpacity", iconOpacityInput.getText().toString());
        editor.putBoolean("outlineOnly", outlineOnlyCheckbox.isChecked());
        editor.putString("dropMode", dropModeSpinner.getSelectedItem().toString());

        editor.apply();

        // Оновлюємо ручні налаштування в DropCorrectionCalculator
        try {
            float windSpeed = Float.parseFloat(windSpeedInput.getText().toString());
            float windAzimuth = Float.parseFloat(windAzimuthInput.getText().toString());

            DropCorrectionCalculator.ManualWindSettings.setWind(windSpeed, windAzimuth);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }


        restartOverlayService();

        finish(); // Закрити екран після збереження
    }

    // Додаємо новий метод:
    private void restartOverlayService() {
        Intent serviceIntent = new Intent(this, OverlayService.class);
        stopService(serviceIntent);
        startService(serviceIntent);
    }
}
