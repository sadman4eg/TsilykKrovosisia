package com.example.herelinkoverlayapp;

// Клас, який обчислює поправки скиду з урахуванням фізики (гравітація, вітер, швидкість, маса)

public class DropCorrectionCalculator {

    public static class Projectile {
        public float massKg;
        public float diameterM;
        public float dragCoefficient;

        public Projectile(float massKg, float diameterM, float dragCoefficient) {
            this.massKg = massKg;
            this.diameterM = diameterM;
            this.dragCoefficient = dragCoefficient;
        }

        public float getFrontalArea() {
            return (float) (Math.PI * Math.pow(diameterM / 2.0, 2));
        }
    }

    public static class Vector2 {
        public float x;
        public float y;

        public Vector2(float x, float y) {
            this.x = x;
            this.y = y;
        }
    }

    // Клас-заглушка для ручного введення в Settings
    public static class ManualWindSettings {
        public static float windSpeed = 0.0f; // м/с
        public static float windAzimuth = 0.0f; // градусів, звідки дме вітер (0 = північ, 90 = схід)

        public static void setWind(float speed, float azimuthDegrees) {
            windSpeed = speed;
            windAzimuth = azimuthDegrees;
        }

        public static Vector2 getWindVector() {
            // Вітер дме ЗВІДКИ -> тому інверсія напряму
            double azimuthRad = Math.toRadians((windAzimuth + 180) % 360);
            float windX = (float) (windSpeed * Math.sin(azimuthRad));
            float windY = (float) (windSpeed * Math.cos(azimuthRad));
            return new Vector2(windX, windY);
        }
    }

    public static Vector2 calculateCorrectionAltHold(
            float altitudeMeters,
            float droneSpeedX, float droneSpeedY,
            float windX, float windY,
            Projectile projectile
    ) {
        final float g = 9.81f;
        final float airDensity = 1.225f;

        float vx = droneSpeedX; // ліво/вправо
        float vy = droneSpeedY; // вперед/назад
        float vz = 0f;

        float px = 0, py = 0, pz = altitudeMeters;

        float dt = 0.01f;
        float dragArea = 0.5f * airDensity * projectile.getFrontalArea() * projectile.dragCoefficient;

        while (pz > 0) {
            float relVx = vx - windX;
            float relVy = vy - windY;
            float relVz = vz;

            float speed = (float) Math.sqrt(relVx * relVx + relVy * relVy + relVz * relVz);

            float fx = -dragArea * speed * relVx;
            float fy = -dragArea * speed * relVy;
            float fz = -dragArea * speed * relVz - projectile.massKg * g;

            float ax = fx / projectile.massKg;
            float ay = fy / projectile.massKg;
            float az = fz / projectile.massKg;

            vx += ax * dt;
            vy += ay * dt;
            vz += az * dt;

            px += vx * dt;
            py += vy * dt;
            pz += vz * dt;
        }

        return new Vector2(px, py); // X — ліво/вправо, Y — вперед/назад
    }


    public enum DropMode {
        LOITER,    // стабілізація, беремо pitch/roll
        ALTHOLD    // дрон в русі, беремо швидкість
    }

    public static Vector2 calculateCorrectionLoiter(
            float altitudeMeters,
            float pitchDegrees, float rollDegrees,
            float windX, float windY,
            Projectile projectile
    ) {
        final float g = 9.81f;
        final float airDensity = 1.225f;

        float pitchRad = (float) Math.toRadians(pitchDegrees);
        float rollRad = (float) Math.toRadians(rollDegrees);

        float vx = g * (float) Math.tan(rollRad);
        float vy = g * (float) Math.tan(pitchRad);

        float verticalVelocity = 0f;
        float time = 0f;
        float dt = 0.01f;

        float dragArea = 0.5f * airDensity * projectile.getFrontalArea() * projectile.dragCoefficient;

        float px = 0;
        float py = altitudeMeters;

        while (py > 0) {
            float relVx = vx - windX;
            float relVy = verticalVelocity - windY;

            float speed = (float) Math.sqrt(relVx * relVx + relVy * relVy);

            float fx = -dragArea * speed * relVx;
            float fy = -dragArea * speed * relVy - projectile.massKg * g;

            float ax = fx / projectile.massKg;
            float ay = fy / projectile.massKg;

            vx += ax * dt;
            verticalVelocity += ay * dt;

            px += vx * dt;
            py += verticalVelocity * dt;

            time += dt;
        }

        return new Vector2(px, py);
    }
}
