package com.example.herelinkoverlayapp;

import com.MAVLink.MAVLinkPacket;
import com.MAVLink.Messages.MAVLinkMessage;
import com.MAVLink.Parser;
import com.MAVLink.common.msg_global_position_int;
import com.MAVLink.common.msg_scaled_imu2;
import android.util.Log;


public class MavLinkHelper {

    private static Parser mavParser = new Parser();

    private static float lastPitch = 0;
    private static float lastRoll = 0;
    private static float lastAltitude = 30; // дефолтна висота

    public static void receiveMavLinkByte(byte data) {
        MAVLinkPacket packet = mavParser.mavlink_parse_char(data);
        if (packet != null) {
            int msgid = packet.msgid;

            Log.d("OverlayService", "Отримано msgid: " + msgid);

            if (msgid == 116) { // SCALED_IMU2
                // Тут поки що треба вручну розпарсити payload
                Log.d("OverlayService", "Отримано SCALED_IMU2!");
            } else if (msgid == 33) { // GLOBAL_POSITION_INT
                Log.d("OverlayService", "Отримано GLOBAL_POSITION_INT!");
            }
        }
    }


    private static void calculatePitchRoll(int xacc, int yacc, int zacc) {
        double x = xacc / 1000.0;
        double y = yacc / 1000.0;
        double z = zacc / 1000.0;

        double pitch = Math.toDegrees(Math.atan2(x, Math.sqrt(y * y + z * z)));
        double roll = Math.toDegrees(Math.atan2(y, Math.sqrt(x * x + z * z)));

        lastPitch = (float) pitch;
        lastRoll = (float) roll;
    }

    public static float getPitch() {
        return lastPitch;
    }

    public static float getRoll() {
        return lastRoll;
    }

    public static float getAltitude() {
        return lastAltitude;
    }
}
