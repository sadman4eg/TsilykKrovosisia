package com.example.herelinkoverlayapp;

public class DroneState {
    private double latitude;
    private double longitude;
    private double altitudeMSL;
    private double realAltitudeAboveGround;

    private float velocityX;
    private float velocityY;
    private float yawDegrees;


    public DroneState(
            double latitude,
            double longitude,
            double altitudeMSL,
            double realAltitudeAboveGround,
            float velocityX,
            float velocityY
            ) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.altitudeMSL = altitudeMSL;
        this.realAltitudeAboveGround = realAltitudeAboveGround;
        this.velocityX = velocityX;
        this.velocityY = velocityY;
    }

    public float getYaw() {
        return yawDegrees;
    }

    public void setYaw(float yaw) {
        this.yawDegrees = yaw;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public double getAltitudeMSL() {
        return altitudeMSL;
    }

    public double getRealAltitudeAboveGround() {
        if (realAltitudeAboveGround < 1.0f) {
            realAltitudeAboveGround = 1.0f;
        }
        return realAltitudeAboveGround;
    }

    public float getVelocityX() {
        return velocityX;
    }

    public float getVelocityY() {
        return velocityY;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public void setAltitudeMSL(double altitudeMSL) {
        this.altitudeMSL = altitudeMSL;
    }

    public void setRealAltitudeAboveGround(double realAltitudeAboveGround) {
        this.realAltitudeAboveGround = realAltitudeAboveGround;
    }
}
