package com.example.herelinkoverlayapp;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import androidx.appcompat.app.AppCompatActivity;
import android.net.Uri;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
            Toast.makeText(this, "Надай дозвіл на оверлеї", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // Якщо дозволи є — стартуємо OverlayService
        Intent serviceIntent = new Intent(this, OverlayService.class);
        startService(serviceIntent);

        // І закриваємо Activity через 0.5 сек
        new android.os.Handler().postDelayed(this::finish, 500);
    }
}
