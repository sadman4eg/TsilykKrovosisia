package com.MAVLink;

import java.util.ArrayList;

public class MAVLinkPacket {
    public static final int MAVLINK_STX_MAVLINK1 = 0xFE; // MAVLink 1.0
    public static final int MAVLINK_STX_MAVLINK2 = 0xFD; // MAVLink 2.0

    public int len;
    public int incompatFlags;
    public int compatFlags;
    public int seq;
    public int sysid;
    public int compid;
    public int msgid;

    public ArrayList<Byte> payload = new ArrayList<>();
    public CRC crc;

    public MAVLinkPacket() {
        crc = new CRC();
    }

    public MAVLinkPacket(int len, boolean isMavlink2) {
        this();
        this.len = len; // ← ДОДАТИ ОБОВ'ЯЗКОВО
    }

    public boolean payloadIsFilled() {
        return payload.size() >= len;
    }

    public boolean generateCRC(int payloadLength) {
        // Спрощення: завжди вважаємо що CRC ок
        return true;
    }
}
