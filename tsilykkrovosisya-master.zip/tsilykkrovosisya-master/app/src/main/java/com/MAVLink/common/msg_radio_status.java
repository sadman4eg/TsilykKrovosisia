package com.MAVLink.common;

import com.MAVLink.Messages.MAVLinkMessage;

public class msg_radio_status extends MAVLinkMessage {

    public static final int MAVLINK_MSG_ID_RADIO_STATUS = 109;

    public int rxerrors;   // uint16_t
    public int fixed;      // uint16_t
    public int rssi;       // uint8_t
    public int remrssi;    // uint8_t
    public int txbuf;      // uint8_t
    public int noise;      // uint8_t
    public int remnoise;   // uint8_t

    public msg_radio_status() {
        this.msgid = MAVLINK_MSG_ID_RADIO_STATUS;
    }
}
