package com.MAVLink.common;

import com.MAVLink.Messages.MAVLinkMessage;

public class msg_global_position_int extends MAVLinkMessage {
    public int time_boot_ms;
    public int lat;
    public int lon;
    public int alt;
    public int relative_alt;
    public int vx;
    public int vy;
    public int vz;
    public int hdg;

    public msg_global_position_int() {
        this.msgid = 33; // ID повідомлення GLOBAL_POSITION_INT
    }
}
