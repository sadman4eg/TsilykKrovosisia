package com.MAVLink;

public class CRC {
    public int crc;

    public CRC() {
        crc = 0;
    }

    public int getLSB() {
        return crc & 0xFF;
    }

    public int getMSB() {
        return (crc >> 8) & 0xFF;
    }
}
