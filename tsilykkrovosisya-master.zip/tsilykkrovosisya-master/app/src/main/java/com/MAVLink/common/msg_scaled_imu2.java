package com.MAVLink.common;

import com.MAVLink.Messages.MAVLinkMessage;

public class msg_scaled_imu2 extends MAVLinkMessage {
    public int time_boot_ms;
    public int xacc;
    public int yacc;
    public int zacc;
    public int xgyro;
    public int ygyro;
    public int zgyro;
    public int xmag;
    public int ymag;
    public int zmag;
    public int temperature;

    public msg_scaled_imu2() {
        this.msgid = 116; // ID повідомлення SCALED_IMU2
    }
}
