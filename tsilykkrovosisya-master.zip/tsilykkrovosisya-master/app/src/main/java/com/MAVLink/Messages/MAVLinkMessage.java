package com.MAVLink.Messages;

public class MAVLinkMessage {
    public int msgid = 0;

    public MAVLinkMessage() {
    }
}
